# Design & Verification of a Low-Power RISC-V SoC Peripheral

**Stage 2: RTL Design — Initial ALU Module**

## Current status

Stage 1 documented the proposed architecture and register map. Stage 2 begins the RTL implementation with a standalone 32-bit arithmetic and logic unit (ALU).

> **Scope note:** The ALU is an initial building block, not a complete RISC-V-connected peripheral. The bus interface, register bank, control FSM, integration, and processor connection will be implemented in later steps. No power, area, timing, or physical-design result is claimed yet.

## Architecture plan

![Proposed RTL architecture](diagrams/peripheral_rtl_architecture.png)

The planned peripheral includes a bus interface, register bank, control FSM, 32-bit ALU, and status/result registers. This diagram describes the intended architecture; it is not evidence that all modules are already implemented.

## Stage 2 objectives

- Implement synthesizable RTL, beginning with the ALU.
- Define opcode behavior for ADD, SUB, AND, OR, and XOR.
- Simulate the module in Vivado.
- Check expected results with a testbench.
- Extend the implementation to the register bank, control FSM, bus interface, and top-level module in subsequent Stage 2 milestones.

## ALU interface

| Signal | Width | Direction | Description |
|---|---:|---|---|
| `operand_a` | 32 | Input | First operand |
| `operand_b` | 32 | Input | Second operand |
| `opcode` | 3 | Input | Selects an operation |
| `result` | 32 | Output | Operation result |

### Opcode map

| Opcode | Operation |
|---|---|
| `3'b000` | Addition |
| `3'b001` | Subtraction |
| `3'b010` | Bitwise AND |
| `3'b011` | Bitwise OR |
| `3'b100` | Bitwise XOR |
| Other values | Result defaults to zero |

The initial arithmetic uses 32-bit unsigned vectors. Overflow/underflow behavior follows 32-bit Verilog expression sizing and is not separately flagged in this version.

## RTL source

See [`rtl/alu.v`](rtl/alu.v).

## Simulation testbench

See [`testbench/alu_tb.v`](testbench/alu_tb.v). It is a simple self-checking testbench using `$display` and `$finish`, suitable for Vivado behavioral simulation. The testbench is not synthesizable hardware.

## Run in Vivado

1. Create or open the Vivado RTL project.
2. Add `rtl/alu.v` under **Design Sources**.
3. Add `testbench/alu_tb.v` under **Simulation Sources**.
4. Set `alu_tb` as the simulation top.
5. Select **Run Simulation → Run Behavioral Simulation**.
6. Check the Tcl Console for `PASS` messages and inspect `result` in the waveform.

## Planned Stage 2 milestones

- [x] Initial ALU RTL drafted
- [x] Basic self-checking simulation testbench drafted
- [ ] Run simulation in Vivado and confirm results
- [ ] Implement register bank
- [ ] Implement control FSM
- [ ] Finalize and implement bus interface
- [ ] Integrate modules in `peripheral_top`
- [ ] Run integrated peripheral simulation

## Tools

- Verilog
- SystemVerilog (planned for a more advanced verification environment)
- AMD Xilinx Vivado
- Cadence / VSD tools later, subject to available tools, licenses, and technology libraries

## Important status statement

The source and testbench are provided as the starting point for Stage 2. Update the checklist only after you have run and verified each step in your own environment.
