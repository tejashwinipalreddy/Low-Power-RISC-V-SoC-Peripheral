# Stage 2 — RTL Design (Initial Milestone)

## Goal
Start RTL implementation of the proposed low-power RISC-V SoC peripheral by building a standalone 32-bit ALU.

## Module
`alu.v`

## Inputs
- `operand_a`: 32-bit first operand
- `operand_b`: 32-bit second operand
- `opcode`: 3-bit operation selector

## Output
- `result`: 32-bit operation result

## Operations
- `000`: ADD
- `001`: SUB
- `010`: AND
- `011`: OR
- `100`: XOR
- Other opcodes: zero result

## Test plan
A basic self-checking Verilog testbench checks the five operations and an unsupported opcode, then exercises bit-pattern cases.

## Next steps
1. Run behavioral simulation in Vivado.
2. Inspect waveforms and console output.
3. Fix any compile/simulation issues.
4. Implement register bank, control FSM, bus interface, and top-level integration.
5. Add SystemVerilog assertions and functional coverage in a later verification stage.

## Status
RTL and testbench files have been drafted. Mark simulation as complete only after running it in Vivado.
