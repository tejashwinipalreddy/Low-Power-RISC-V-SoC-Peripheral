`timescale 1ns / 1ps

// 32-bit combinational Arithmetic Logic Unit (ALU)
// This is a standalone building block for the planned SoC peripheral.
module alu (
    input  wire [31:0] operand_a,
    input  wire [31:0] operand_b,
    input  wire [2:0]  opcode,
    output reg  [31:0] result
);

    always @(*) begin
        case (opcode)
            3'b000: result = operand_a + operand_b; // ADD
            3'b001: result = operand_a - operand_b; // SUB
            3'b010: result = operand_a & operand_b; // AND
            3'b011: result = operand_a | operand_b; // OR
            3'b100: result = operand_a ^ operand_b; // XOR
            default: result = 32'b0;                 // Unsupported opcode
        endcase
    end

endmodule
