`timescale 1ns / 1ps

// Basic self-checking testbench for the standalone ALU.
// Add this file as a Simulation Source in Vivado.
module alu_tb;

    reg  [31:0] operand_a;
    reg  [31:0] operand_b;
    reg  [2:0]  opcode;
    wire [31:0] result;

    integer errors;

    alu dut (
        .operand_a(operand_a),
        .operand_b(operand_b),
        .opcode(opcode),
        .result(result)
    );

    task check_result;
        input [31:0] expected;
        input [8*40-1:0] test_name;
        begin
            #10;
            if (result !== expected) begin
                $display("FAIL: %0s | expected=%h actual=%h",
                         test_name, expected, result);
                errors = errors + 1;
            end else begin
                $display("PASS: %0s | result=%h", test_name, result);
            end
        end
    endtask

    initial begin
        operand_a = 32'd10;
        operand_b = 32'd5;
        opcode = 3'b000;
        errors = 0;

        check_result(32'd15, "ADD");

        opcode = 3'b001;
        check_result(32'd5, "SUB");

        opcode = 3'b010;
        check_result(32'd0, "AND");

        opcode = 3'b011;
        check_result(32'd15, "OR");

        opcode = 3'b100;
        check_result(32'd15, "XOR");

        opcode = 3'b111;
        check_result(32'd0, "INVALID OPCODE");

        // A second set of operands exercises bit patterns.
        operand_a = 32'hA5A5_00FF;
        operand_b = 32'h0F0F_FF00;

        opcode = 3'b010;
        check_result(32'h0505_0000, "AND PATTERN");

        opcode = 3'b011;
        check_result(32'hAFAF_FFFF, "OR PATTERN");

        opcode = 3'b100;
        check_result(32'hAAAA_FFFF, "XOR PATTERN");

        if (errors == 0)
            $display("ALL TESTS PASSED");
        else
            $display("TESTS FAILED: %0d error(s)", errors);

        $finish;
    end

endmodule
